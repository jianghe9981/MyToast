//
//  MyToast.swift
//  PodTest
//
//  Created by mac on 2021/8/26.
//

import UIKit

open class MyToast: NSObject {

    public static func show() {
        puts(#function)
    }
}
